export class Calculo {
    id?: number;
    idTecnico: string;
    numSemana: number;
  }