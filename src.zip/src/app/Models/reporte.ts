export class Reporte {
    id?: number;
    nombre:string;
    descripcion: string;
    idServicio: string;
    idTecnico: string;
    fechaInicio: Date;
    fechaFin: Date;
}