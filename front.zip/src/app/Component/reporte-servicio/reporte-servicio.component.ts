import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reporte-servicio',
  templateUrl: './reporte-servicio.component.html',
  styleUrls: ['./reporte-servicio.component.css']
})
export class ReporteServicioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  onCreate():void {
    
  }
}
