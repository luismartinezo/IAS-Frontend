import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculo-horas',
  templateUrl: './calculo-horas.component.html',
  styleUrls: ['./calculo-horas.component.css']
})
export class CalculoHorasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  onCreate():void {
    
  }
}
